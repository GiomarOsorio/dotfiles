#! /bin/bash 
picom &
nitrogen --restore &
urxvtd -q -o -f &
megasync &
flameshot &
redshift &
discord &
